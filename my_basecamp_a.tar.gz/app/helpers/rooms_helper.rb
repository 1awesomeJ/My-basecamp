module RoomsHelper
end
